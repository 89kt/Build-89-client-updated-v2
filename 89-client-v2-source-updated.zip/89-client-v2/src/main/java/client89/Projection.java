package client89;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

public final class Projection {
    public static Pt project(MinecraftClient mc, float td, Vec3d target, int w, int h) {
        ClientPlayerEntity p = mc.player;
        Vec3d cam = p.getCameraPosVec(td);
        double yaw = Math.toRadians(p.getYaw(td));
        double pitch = Math.toRadians(p.getPitch(td));
        Vec3d fwd = new Vec3d(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
        Vec3d right = new Vec3d(-Math.cos(yaw), 0.0, -Math.sin(yaw));
        Vec3d up = right.crossProduct(fwd);
        Vec3d d = target.subtract(cam);
        double f = d.dotProduct(fwd);
        double r = d.dotProduct(right);
        double u = d.dotProduct(up);
        double t = Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2.0);
        double aspect = (double) w / (double) h;
        if (f <= 0.05) {
            double m = Math.hypot(r, u);
            if (m < 1.0E-4) { r = 1.0; m = 1.0; }
            return new Pt((float) (w / 2.0 + r / m * w), (float) (h / 2.0 - u / m * w), true);
        }
        double nx = r / (f * t * aspect);
        double ny = u / (f * t);
        return new Pt((float) (w / 2.0 * (1.0 + nx)), (float) (h / 2.0 * (1.0 - ny)), false);
    }

    public record Pt(float x, float y, boolean behind) { }
}

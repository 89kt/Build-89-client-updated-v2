package client89;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix3x2fStack;

public final class Tracers {
    public static void render(DrawContext c, MinecraftClient mc, float td) {
        if (!mc.options.getPerspective().isFirstPerson()) return;
        int w = c.getScaledWindowWidth();
        int h = c.getScaledWindowHeight();
        float range = Modules.TRACERS.setting.value; // up to 1000 blocks
        Vec3d cam = mc.player.getCameraPosVec(td);
        float cx = w / 2.0f, cy = h / 2.0f;
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || p.isSpectator()) continue;
            Vec3d tp = p.getLerpedPos(td).add(0.0, p.getHeight() * 0.5, 0.0);
            double dist = cam.distanceTo(tp);
            if (dist > range) continue;
            Projection.Pt pt = Projection.project(mc, td, tp, w, h);
            float t = (float) MathHelper.clamp(dist / range, 0.0, 1.0);
            int col = Render2D.lerp(Theme.accent(), 0xFFFFFFFF, (float) Math.sqrt(t) * 0.55f);
            col = Render2D.alpha(col, 0.95f);
            float dx = pt.x() - cx, dy = pt.y() - cy;
            float len = (float) Math.sqrt(dx * dx + dy * dy);
            if (len < 12.0f) continue;
            float sx = cx + dx / len * 8.0f, sy = cy + dy / len * 8.0f;
            // soft dark shadow line under the coloured one so it stays readable on bright sky
            Render2D.line(c, sx, sy + 1, pt.x(), pt.y() + 1, Render2D.alpha(0xFF000000, 0.25f));
            Render2D.line(c, sx, sy, pt.x(), pt.y(), col);
            if (pt.behind() || pt.x() <= 0 || pt.x() >= w || pt.y() <= 0 || pt.y() >= h) continue;
            Render2D.rrect(c, (int) pt.x() - 2, (int) pt.y() - 2, 5, 5, 2, col);
            String label = Math.round(dist) + "m";
            Matrix3x2fStack m = c.getMatrices();
            m.pushMatrix();
            m.translate(pt.x() + 5.0f, pt.y() - 3.0f);
            m.scale(0.75f, 0.75f);
            c.drawText(mc.textRenderer, label, 0, 0, col, true);
            m.popMatrix();
        }
    }
}

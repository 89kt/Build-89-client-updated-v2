package client89;

import java.util.ArrayList;
import java.util.List;

public class Module {
    public final String name;
    public final String desc;
    public final String category;
    public boolean enabled;
    public float anim;
    public boolean expanded;
    /** First setting (kept so old code like Modules.NAMETAGS.setting.value still works). */
    public Setting setting;
    public final List<Setting> settings = new ArrayList<>();

    public Module(String category, String name, String desc, boolean enabled) {
        this.category = category;
        this.name = name;
        this.desc = desc;
        this.enabled = enabled;
        this.anim = enabled ? 1.0f : 0.0f;
    }

    public Module setting(Setting s) {
        settings.add(s);
        if (setting == null) setting = s;
        return this;
    }

    public void toggle() { this.enabled = !this.enabled; Modules.save(); }

    public void tick() { this.anim += ((this.enabled ? 1.0f : 0.0f) - this.anim) * 0.18f; }

    public static class Setting {
        public enum Kind { SLIDER, CHOICE, COLOR }

        public final Kind kind;
        public final String name;
        // slider
        public final float min, max;
        public final int decimals;
        public float value;
        // choice / colour (index into options or Theme.PALETTE)
        public final String[] options;
        public int index;
        /** Called after the user changes this setting in the GUI (used for previews). */
        public Runnable onChange;

        /** Slider. */
        public Setting(String name, float min, float max, float value, int decimals) {
            this.kind = Kind.SLIDER;
            this.name = name; this.min = min; this.max = max; this.value = value; this.decimals = decimals;
            this.options = null;
        }

        private Setting(Kind kind, String name, String[] options, int index) {
            this.kind = kind; this.name = name; this.options = options; this.index = index;
            this.min = 0; this.max = 1; this.decimals = 0; this.value = 0;
        }

        /** Click-to-cycle list of options. */
        public static Setting choice(String name, int def, String... options) {
            return new Setting(Kind.CHOICE, name, options, def);
        }

        /** Row of colour swatches (Theme.PALETTE). */
        public static Setting color(String name, int defIndex) {
            return new Setting(Kind.COLOR, name, null, defIndex);
        }

        public Setting onChange(Runnable r) { this.onChange = r; return this; }

        public float pct() { return (value - min) / (max - min); }

        public String text() {
            if (kind == Kind.CHOICE) return options[index];
            return String.format("%." + decimals + "f", value);
        }
    }
}

package client89;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

public class Client89 implements ClientModInitializer {
    public static KeyBinding openKey;
    private static int tickCounter;

    @Override
    public void onInitializeClient() {
        Modules.load();
        Modules.save(); // writes discord.clientId into the config so it is easy to find
        KeyBinding.Category cat = KeyBinding.Category.create(Identifier.of("client89", "client"));
        openKey = KeyBindingHelper.registerKeyBinding(
            new KeyBinding("key.client89.gui", InputUtil.Type.KEYSYM, 80, cat));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openKey.wasPressed()) {
                if (mc.currentScreen == null) mc.setScreen(new ClickGui());
            }
            if (++tickCounter % 20 == 0) Discord.tick(mc);
        });
        HudRenderCallback.EVENT.register(Hud::render);

        // hit particles + hit sound
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient() && entity instanceof LivingEntity le && le.isAlive()) {
                Vec3d at = le.getLerpedPos(1.0f).add(0.0, le.getHeight() * 0.65, 0.0);
                HitFx.hit(at);
                HitSound.hit();
            }
            return ActionResult.PASS;
        });

        Discord.start();
    }
}

package client89;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import net.minecraft.util.Util;
import net.minecraft.util.math.MathHelper;
import org.joml.Matrix3x2fStack;

/** Column GUI: one white panel per category, search bar + colour dots at the bottom. */
public class ClickGui extends Screen {
    private static final int GAP = 10;
    private static final int HEAD = 22;
    private static final int ROW = 17;
    private static final int TOP = 36;

    private record Row(Module mod, Module.Setting st, int y, int h) { }

    private final Screen parent;
    private final long opened = Util.getMeasuringTimeMs();
    private TextFieldWidget search;
    private Module.Setting dragging;
    private int dragX, dragW;

    public ClickGui() { this(null); }

    public ClickGui(Screen parent) {
        super(Text.literal("89 client v2"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        search = new TextFieldWidget(textRenderer, width / 2 - 78, height - 54, 156, 16, Text.literal("Search"));
        search.setDrawsBackground(false);
        search.setPlaceholder(Text.literal("Search..."));
        search.setMaxLength(24);
        addDrawableChild(search);
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void close() {
        if (parent != null && client != null) client.setScreen(parent);
        else super.close();
    }

    private float anim() {
        return Render2D.ease(MathHelper.clamp((Util.getMeasuringTimeMs() - opened) / 280.0f, 0.0f, 1.0f));
    }

    private double mouseX() {
        MinecraftClient mc = MinecraftClient.getInstance();
        return mc.mouse.getX() * mc.getWindow().getScaledWidth() / (double) mc.getWindow().getWidth();
    }
    private double mouseY() {
        MinecraftClient mc = MinecraftClient.getInstance();
        return mc.mouse.getY() * mc.getWindow().getScaledHeight() / (double) mc.getWindow().getHeight();
    }

    private List<Module> modulesOf(String cat) {
        String q = search == null ? "" : search.getText().toLowerCase().trim();
        List<Module> out = new ArrayList<>();
        for (Module m : Modules.ALL) {
            if (m.category.equals(cat) && (q.isEmpty() || m.name.toLowerCase().contains(q))) out.add(m);
        }
        return out;
    }

    // ---- layout ----

    private int pw() {
        int n = Modules.CATEGORIES.size();
        return Math.max(96, Math.min(150, (width - 24 - (n - 1) * GAP) / n));
    }

    private int panelX(int col) {
        int n = Modules.CATEGORIES.size();
        int pw = pw();
        int total = n * pw + (n - 1) * GAP;
        return (width - total) / 2 + col * (pw + GAP);
    }

    private int settingH(Module.Setting s) {
        return switch (s.kind) {
            case SLIDER -> 22;
            case CHOICE -> 19;
            case COLOR -> 27;
        };
    }

    private List<Row> rows(String cat) {
        List<Row> out = new ArrayList<>();
        int y = TOP + 8 + HEAD + 2;
        for (Module m : modulesOf(cat)) {
            out.add(new Row(m, null, y, ROW));
            y += ROW;
            if (m.expanded) {
                for (Module.Setting s : m.settings) {
                    int h = settingH(s);
                    out.add(new Row(m, s, y, h));
                    y += h;
                }
            }
        }
        return out;
    }

    private int panelH(String cat) {
        List<Row> r = rows(cat);
        int end = r.isEmpty() ? TOP + 8 + HEAD + 2 : r.get(r.size() - 1).y() + r.get(r.size() - 1).h();
        return end + 4 - (TOP + 8);
    }

    private int dotsX() { int n = Theme.COLORS.length; return (width - (n * 14 + 12)) / 2; }

    private int swatchX(int i, int rx, int rw) {
        int n = Theme.PALETTE.length;
        float step = (rw - 12 - 10) / (float) (n - 1);
        return rx + 6 + Math.round(i * step);
    }

    // ---- drawing ----

    @Override
    public void renderBackground(DrawContext c, int mx, int my, float delta) {
        float a = anim();
        c.fill(0, 0, width, height, Render2D.alpha(0x66FFFFFF, a * 0.55f));
        Matrix3x2fStack m = c.getMatrices();
        m.pushMatrix();
        float s = 0.94f + 0.06f * a;
        m.translate(width / 2.0f, height / 2.0f);
        m.scale(s, s);
        m.translate(-width / 2.0f, -height / 2.0f);

        Render2D.wave(c, textRenderer, "89 client v2", width / 2 - textRenderer.getWidth("89 client v2") / 2, 12, a);
        Render2D.centered(c, textRenderer, "made by 89_kt", width / 2, 24, Render2D.alpha(Theme.DIM, a), false);

        int pw = pw();
        for (int col = 0; col < Modules.CATEGORIES.size(); col++) {
            String cat = Modules.CATEGORIES.get(col);
            int px = panelX(col), py = TOP + 8, ph = panelH(cat);
            Render2D.rrect(c, px - 1, py - 1, pw + 2, ph + 2, 7, Render2D.alpha(Theme.accent(), 0.22f * a));
            Render2D.rrect(c, px, py, pw, ph, 6, Render2D.alpha(Theme.PANEL, a));
            Render2D.centered(c, textRenderer, cat, px + pw / 2, py + 7, Render2D.alpha(Theme.TEXT, a), false);
            Render2D.hgrad(c, px + 10, py + HEAD - 3, pw - 20, 1, Render2D.alpha(Theme.accent(), a), Render2D.alpha(Theme.accent2(), a));
            int rx = px + 4, rw = pw - 8;
            for (Row r : rows(cat)) {
                if (r.st() == null) drawModule(c, r, rx, rw, mx, my, a);
                else drawSetting(c, r.st(), rx, rw, r.y(), a);
            }
        }

        Render2D.rrect(c, width / 2 - 84, height - 58, 168, 22, 8, Render2D.alpha(Theme.PANEL, a));

        int n = Theme.COLORS.length;
        int dx = dotsX();
        Render2D.rrect(c, dx, height - 32, n * 14 + 12, 18, 9, Render2D.alpha(Theme.PANEL, a));
        for (int i = 0; i < n; i++) {
            int cx = dx + 8 + i * 14;
            if (i == Theme.index) Render2D.rrect(c, cx - 1, height - 29, 12, 12, 6, Render2D.alpha(Theme.COLORS[i], 0.35f * a));
            Render2D.rrect(c, cx + 1, height - 27, 8, 8, 4, Render2D.alpha(Theme.COLORS[i], a));
        }
        Render2D.centered(c, textRenderer, "left click: toggle / change   right click: settings   P: close",
            width / 2, height - 12, Render2D.alpha(Theme.DIM, a), false);
        m.popMatrix();
    }

    private void drawModule(DrawContext c, Row r, int rx, int rw, int mx, int my, float a) {
        Module mod = r.mod();
        int y = r.y();
        boolean hov = mx >= rx && mx < rx + rw && my >= y && my < y + ROW;
        int base = hov ? Theme.ROW_HOVER : 0x00FFFFFF;
        Render2D.rrect(c, rx, y, rw, ROW - 1, 4, Render2D.alpha(base, a));
        Render2D.rrect(c, rx, y, rw, ROW - 1, 4, Render2D.alpha(Theme.accent(), a * mod.anim));
        int tcol = Render2D.lerp(Theme.TEXT, Theme.WHITE, mod.anim);
        c.drawText(textRenderer, mod.name, rx + 6, y + 4, Render2D.alpha(tcol, a), false);
        if (!mod.settings.isEmpty()) {
            String arrow = mod.expanded ? "-" : "+";
            c.drawText(textRenderer, arrow, rx + rw - 10, y + 4,
                Render2D.alpha(Render2D.lerp(Theme.DIM, Theme.WHITE, mod.anim), a), false);
        }
    }

    private void drawSetting(DrawContext c, Module.Setting st, int rx, int rw, int y, float a) {
        switch (st.kind) {
            case SLIDER -> {
                c.drawText(textRenderer, st.name, rx + 6, y + 1, Render2D.alpha(Theme.DIM, a), false);
                String v = st.text();
                c.drawText(textRenderer, v, rx + rw - 6 - textRenderer.getWidth(v), y + 1, Render2D.alpha(Theme.TEXT, a), false);
                int sx = rx + 6, sw = rw - 12, sy = y + 13;
                Render2D.rrect(c, sx, sy, sw, 3, 1, Render2D.alpha(Theme.TRACK, a));
                int fw = (int) (sw * st.pct());
                Render2D.hgrad(c, sx, sy, Math.max(fw, 1), 3, Render2D.alpha(Theme.accent(), a), Render2D.alpha(Theme.accent2(), a));
                Render2D.rrect(c, sx + fw - 3, sy - 2, 7, 7, 3, Render2D.alpha(Theme.accent(), a));
                Render2D.rrect(c, sx + fw - 2, sy - 1, 5, 5, 2, Render2D.alpha(Theme.WHITE, a));
            }
            case CHOICE -> {
                Render2D.rrect(c, rx + 6, y + 1, rw - 12, 16, 4, Render2D.alpha(Theme.ROW_HOVER, a));
                c.drawText(textRenderer, st.name, rx + 10, y + 5, Render2D.alpha(Theme.DIM, a), false);
                String v = st.text();
                c.drawText(textRenderer, v, rx + rw - 10 - textRenderer.getWidth(v), y + 5, Render2D.alpha(Theme.accent(), a), false);
            }
            case COLOR -> {
                c.drawText(textRenderer, st.name, rx + 6, y + 1, Render2D.alpha(Theme.DIM, a), false);
                for (int i = 0; i < Theme.PALETTE.length; i++) {
                    int sx = swatchX(i, rx, rw), sy = y + 13;
                    boolean sel = i == st.index;
                    Render2D.rrect(c, sx - 1, sy - 1, 12, 12, 4, Render2D.alpha(sel ? Theme.TEXT : Theme.TRACK, a));
                    int entry = Theme.PALETTE[i];
                    if (entry == 1) {
                        Render2D.rrect(c, sx, sy, 10, 10, 3, Render2D.alpha(Theme.resolve(1, 0.5f), a));
                        for (int k = 0; k < 10; k += 2) {
                            c.fill(sx + k, sy + 2, sx + k + 2, sy + 8, Render2D.alpha(Theme.resolve(1, k / 10.0f), a));
                        }
                    } else {
                        Render2D.rrect(c, sx, sy, 10, 10, 3, Render2D.alpha(Theme.resolve(entry, 0f), a));
                    }
                }
            }
        }
    }

    // ---- input ----

    private void setFrom(double mx) {
        float p = (float) MathHelper.clamp((mx - dragX) / (double) dragW, 0.0, 1.0);
        float v = dragging.min + p * (dragging.max - dragging.min);
        float f = (float) Math.pow(10, dragging.decimals);
        dragging.value = Math.round(v * f) / f;
    }

    private void changed(Module.Setting s) {
        Modules.save();
        if (s.onChange != null) s.onChange.run();
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = mouseX(), my = mouseY();
        int btn = click.button();

        int n = Theme.COLORS.length, dx = dotsX();
        if (btn == 0 && my >= height - 32 && my < height - 14) {
            for (int i = 0; i < n; i++) {
                int cx = dx + 8 + i * 14;
                if (mx >= cx - 2 && mx < cx + 12) { Theme.index = i; Modules.save(); return true; }
            }
        }

        int pw = pw();
        for (int col = 0; col < Modules.CATEGORIES.size(); col++) {
            String cat = Modules.CATEGORIES.get(col);
            int px = panelX(col);
            int rx = px + 4, rw = pw - 8;
            if (mx < rx || mx >= rx + rw) continue;
            for (Row r : rows(cat)) {
                if (my < r.y() || my >= r.y() + r.h()) continue;
                Module.Setting st = r.st();
                if (st == null) {
                    if (btn == 0) r.mod().toggle();
                    else if (btn == 1 && !r.mod().settings.isEmpty()) r.mod().expanded = !r.mod().expanded;
                    return true;
                }
                switch (st.kind) {
                    case SLIDER -> {
                        if (btn != 0) return true;
                        dragging = st;
                        dragX = rx + 6;
                        dragW = rw - 12;
                        setFrom(mx);
                    }
                    case CHOICE -> {
                        int len = st.options.length;
                        st.index = btn == 1 ? (st.index - 1 + len) % len : (st.index + 1) % len;
                        changed(st);
                    }
                    case COLOR -> {
                        if (btn != 0 || my < r.y() + 11 || my >= r.y() + 26) return true;
                        for (int i = 0; i < Theme.PALETTE.length; i++) {
                            int sx = swatchX(i, rx, rw);
                            if (mx >= sx - 1 && mx < sx + 11) { st.index = i; changed(st); break; }
                        }
                    }
                }
                return true;
            }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double dx, double dy) {
        if (dragging != null) { setFrom(mouseX()); return true; }
        return super.mouseDragged(click, dx, dy);
    }

    @Override
    public boolean mouseReleased(Click click) {
        if (dragging != null) {
            Module.Setting s = dragging;
            dragging = null;
            changed(s);
            return true;
        }
        return super.mouseReleased(click);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        if (input.getKeycode() == 80 && !(search != null && search.isFocused())) {
            close();
            return true;
        }
        return super.keyPressed(input);
    }
}
